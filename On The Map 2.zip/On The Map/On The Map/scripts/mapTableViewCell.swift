//
//  TableCell.swift
//  On The Map
//
//  Created by Sergey on 29/12/19.
//  Copyright © 2019 Sergey. All rights reserved.
//

import Foundation
import UIKit

class mapTableViewCell: UITableViewCell {
    
    @IBOutlet weak var mapTableImage: UIImageView!
    @IBOutlet weak var topTextNameLabelTableView: UILabel!
    @IBOutlet weak var URLLabelTableView: UILabel!
}
