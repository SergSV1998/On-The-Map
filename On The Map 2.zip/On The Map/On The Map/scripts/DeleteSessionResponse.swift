//
//  Response 1.0.swift
//  On The Map
//
//  Created by Sergey on 30/12/19.
//  Copyright © 2019 Sergey. All rights reserved.
//

import Foundation

class deleteSessionResponse {
    struct DeleteResponse {
        static var sessionId =  "id"
        static var expiration =  "expiration"
    }
    
    
}
