//
//  Response 5.0.swift
//  On The Map
//
//  Created by Sergey on 30/12/19.
//  Copyright © 2019 Sergey. All rights reserved.
//

import Foundation

class putLocation {
    
    struct PutStudentLocationResponse {
        var updatedAt: String
    }
}
