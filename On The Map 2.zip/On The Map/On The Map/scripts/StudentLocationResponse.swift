///Users/sergey/iCloud Drive (архив)/Desktop/On The Map/On The Map/StudentLocationResponse.swift
//  Response 4.0.swift
//  On The Map
//
//  Created by Sergey on 30/12/19.
//  Copyright © 2019 Sergey. All rights reserved.
//
import Foundation
class postLocationResponse {
    struct postLocationResponse {
       static var createdAt = "createdAt"
       static var objectId = "objectId"
    }
    
}
